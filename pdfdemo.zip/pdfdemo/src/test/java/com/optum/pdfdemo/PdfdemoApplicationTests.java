package com.optum.pdfdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PdfdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
