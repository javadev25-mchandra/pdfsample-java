package com.optum.pdfdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PdfdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(PdfdemoApplication.class, args);
	}

}
